import { StyleSheet } from 'react-native';


const styles = StyleSheet.create({
 
  pageChange:{
    
  cursor: 'pointer',
  color:'white',
  backgroundColor:'blue',
  width:120,
  borderRadius: 30,
  marginTop: 15 ,
  marginLeft:110,

  },
});


export { styles };